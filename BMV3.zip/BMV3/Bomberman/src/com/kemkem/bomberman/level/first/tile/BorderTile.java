package com.kemkem.bomberman.level.first.tile;

import com.kemkem.bomberman.graphics.Screen;
import com.kemkem.bomberman.graphics.Sprite;
import com.kemkem.bomberman.level.tile.Tile;

public class BorderTile extends Tile {

	public BorderTile(Sprite sprite) {
		super(sprite);
		removed = false;
	}
	
	public void render(int x, int y, Screen screen) {
		screen.renderTile(x << 6, y << 6, this);
	}
	
	public boolean solid() {
		return true;
	}
	
	public boolean isRemove() {
		return removed;
	}

}
