package com.kemkem.bomberman.entity;

import com.kemkem.bomberman.graphics.Screen;
import com.kemkem.bomberman.graphics.Sprite;
import com.kemkem.bomberman.level.Level;

public class Entity {
	
	protected int x, y;
	public boolean removed;
	protected Sprite sprite;
	protected Level level;
	
	public void update() {
		
	}
	
	public void remove() {
		
	}
	
	public void render(Screen screen) {
		
	}

}
