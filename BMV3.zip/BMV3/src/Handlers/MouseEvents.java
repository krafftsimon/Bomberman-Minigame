package Handlers;

import java.awt.Font;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import windows.CreditsWindow;
import windows.MainWindow;
import windows.Menu;
import windows.OptionsWindow;



public class MouseEvents implements MouseListener{
	MainWindow mw;
	OptionsWindow op;
	CreditsWindow credits;
	Menu menu;
	Font font1 = new Font("Arial", Font.BOLD, 20);
	Font font2 = new Font("Arial", Font.BOLD, 30);
	
	public MouseEvents(MainWindow mw) {
		this.mw = mw;
		//mw.setVisible(false);
	}

	public void mouseClicked(MouseEvent e) {
		if(e.getComponent() == mw.new_Game) {
			//start game
		}
		else if(e.getComponent() == mw.load_Game) {
			
		}
		else if(e.getComponent() == mw.options) {
			//bring up options menu
			op = new OptionsWindow();
		}
		else if(e.getComponent() == mw.credits) {
			credits = new CreditsWindow();
		}
		else if(e.getComponent() == mw.quit) {
			System.exit(1);
		}
		
	}

	
	public void mouseEntered(MouseEvent e) {
		if (e.getComponent() == mw.new_Game) {
			mw.new_Game.setFont(font2);
		}
		else if(e.getComponent() == mw.load_Game) {
			mw.load_Game.setFont(font2);
		}
		else if(e.getComponent() == mw.options) {
			mw.options.setFont(font2);
		}
		else if(e.getComponent() == mw.credits) {
			mw.credits.setFont(font2);
		}
		else if(e.getComponent() == mw.quit) {
			mw.quit.setFont(font2);
		}
		
	}

	
	public void mouseExited(MouseEvent e) {
		if (e.getComponent() == mw.new_Game) {
			mw.new_Game.setFont(font1);
		}
		else if(e.getComponent() == mw.load_Game) {
			mw.load_Game.setFont(font1);
		}
		else if(e.getComponent() == mw.options) {
			mw.options.setFont(font1);
		}
		else if(e.getComponent() == mw.credits) {
			mw.credits.setFont(font1);
		}
		else if(e.getComponent() == mw.quit) {
			mw.quit.setFont(font1);
		}
		
	}


	public void mousePressed(MouseEvent e) {
		
		
	}

	
	public void mouseReleased(MouseEvent e) {
	
		
	}
}
