package Handlers;


import java.awt.Window;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

import windows.MainWindow;
import windows.Menu;

public class KeyEvents implements KeyListener{
	Menu menu;
	MainWindow mw;
	
	public KeyEvents() {
		
		//menu = new Menu();
		//menu.setVisible(true);
	}

	
	public void keyPressed(KeyEvent e) {
		e.consume();
		
	}
	
	public void keyReleased(KeyEvent e) {
		if(e.getKeyCode() == KeyEvent.VK_SPACE ) {
			
			//menu.setVisible(false);
			mw = new MainWindow();
			
		}
	}

	public void keyTyped(KeyEvent e) {
		e.consume();	
	}
}