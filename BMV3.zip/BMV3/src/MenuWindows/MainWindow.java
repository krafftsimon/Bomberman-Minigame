package MenuWindows;

import java.awt.Color;

import java.awt.Font;
import java.awt.Image;

import javax.imageio.ImageIO;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import Handlers.MouseEvents;

import java.awt.SystemColor;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.swing.ImageIcon;

import windows.Menu;
import windows.OptionsWindow;

import java.awt.Toolkit;

public class MainWindow extends JFrame {
	public JButton new_Game;
	public JButton load_Game;
	public JButton options;
	public JButton credits;
	public JButton quit;
	Font font1 = new Font("Arial", Font.BOLD, 20);
	Font font2 = new Font("Arial", Font.BOLD, 30);
	OptionsWindow optionsWin;
	CreditsWindow creditsWin;
	MouseEvents mouse;
	Menu menu;
	MainWindow mw;

	private static final long serialVersionUID = 1L;
	private JLabel label;
	
	public MainWindow() {
		
		display();
		
	}
	
	public void display() {
		
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setBounds(100, 100, 600, 600);
		
		JPanel panel = new JPanel();
		panel.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(panel);
		panel.setLayout(null);
		panel.setBackground(SystemColor.inactiveCaption);
		
		JLabel title = new JLabel("Bomberman Reloaded");
		title.setBounds(117, 22, 333, 23);
		title.setFont(font2);
		title.setForeground(new Color(0, 128, 128));
		panel.add(title);
		
		mouse = new MouseEvents(mw);
		//panel.addMouseListener(mouse);
		
		new_Game = new JButton("New Game");
		new_Game.setBounds(182, 75, 189, 23);
		new_Game.setBorderPainted(false);
		new_Game.setContentAreaFilled(false);
		new_Game.setFocusPainted(false);
		new_Game.setOpaque(false);
		new_Game.setFont(font1);
		new_Game.setForeground(SystemColor.desktop);
		new_Game.addMouseListener(mouse);
			
		panel.add(new_Game);
		
		load_Game = new JButton("Load Game");
		load_Game.setBounds(182, 195, 208, 23);
		load_Game.setBorderPainted(false);
		load_Game.setContentAreaFilled(false);
		load_Game.setFocusPainted(false);
		load_Game.setOpaque(false);
		load_Game.setFont(font1);
		load_Game.setForeground(SystemColor.controlText);
		load_Game.addMouseListener(mouse);
		
		panel.add(load_Game);
		
		options = new JButton("Options");
		options.setBounds(182, 305, 189, 23);
		options.setBorderPainted(false);
		options.setContentAreaFilled(false);
		options.setFocusPainted(false);
		options.setOpaque(false);
		options.setFont(font1);
		options.setForeground(SystemColor.controlText);
		options.addMouseListener(mouse);
		
		panel.add(options);
		
		credits = new JButton("Credits");
		credits.setBounds(182, 420, 189, 23);
		credits.setBorderPainted(false);
		credits.setContentAreaFilled(false);
		credits.setFocusPainted(false);
		credits.setOpaque(false);
		credits.setFont(font1);
		credits.setForeground(SystemColor.controlText);
		credits.addMouseListener(mouse);
	
		panel.add(credits);
		
		quit = new JButton("Quit");
		quit.setBounds(182, 535, 189, 23);
		quit.setBorderPainted(false);
		quit.setContentAreaFilled(false);
		quit.setFocusPainted(false);
		quit.setOpaque(false);
		quit.setFont(font1);
		quit.setForeground(SystemColor.controlText);
		quit.addMouseListener(mouse);
		
		panel.add(quit);
		
		label = new JLabel("");
		ImageIcon im = new ImageIcon("C:\\Users\\user\\Desktop\\Bomberman.jpg");
		
		label.setIcon(im);
		
		label.setBounds(0, 0, 584, 562);
		
		panel.add(label);
		
		
		
	
		}
	}