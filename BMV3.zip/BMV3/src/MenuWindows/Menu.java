package MenuWindows;
import java.awt.Color;
import java.awt.Font;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import Handlers.KeyEvents;

import java.awt.SystemColor;


public class Menu extends JFrame{
	
	KeyEvents keys;
	Menu menu;
	MainWindow mw;
	


		public void render() 
		{
			
			this.setVisible(true);	
			this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			this.setResizable(false);
			setBounds(100, 100, 600, 600);
			Font font1 = new Font("Arial", Font.BOLD, 40);
			JPanel panel = new JPanel();
	
			panel.setBorder(new EmptyBorder(5, 5, 5, 5));
			this.setContentPane(panel);
			panel.setLayout(null);
			panel.setBackground(new Color(0, 100, 0));
			panel.setFocusable(true);
	
			JLabel title = new JLabel("Bomberman Reloaded");
			title.setBounds(78, 11, 472, 34);
			title.setFont(new Font("Segoe Print", Font.BOLD, 40));
			title.setForeground(SystemColor.textHighlight);
			panel.add(title);
	
			JLabel start_Game = new JLabel("Press The Spacebar");
			start_Game.setFont(new Font("Tahoma", Font.PLAIN, 18));
			start_Game.setBounds(236, 333, 168, 14);
			start_Game.setForeground(new Color(0, 0, 0));
			
			keys = new KeyEvents();
			
			panel.addKeyListener(keys);
			
			panel.add(start_Game);
	
		}
}

