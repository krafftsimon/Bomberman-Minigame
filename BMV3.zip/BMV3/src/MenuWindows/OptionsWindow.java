package MenuWindows;

import java.awt.Color;
import java.awt.Font;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JSlider;
import javax.swing.border.EmptyBorder;

@SuppressWarnings("serial")
public class OptionsWindow extends JFrame{


	public OptionsWindow() {
		display();
	}

	public void display() {

		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 600, 600);
		final Font font1 = new Font("Arial", Font.BOLD, 14);
		final Font font2 = new Font("Arial", Font.BOLD, 24);
		JPanel optionsWindow = new JPanel();

		optionsWindow.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(optionsWindow);
		optionsWindow.setLayout(null);
		optionsWindow.setBackground(Color.GRAY);
		JLabel title = new JLabel("Options");
		title.setBounds(212, 11, 113, 34);
		title.setFont(font2);
		title.setForeground(Color.WHITE);
		optionsWindow.add(title);

		JLabel sfx = new JLabel("SFX Volume");
		sfx.setBounds(62, 68, 106, 23);
		sfx.setForeground(Color.WHITE);
		sfx.setFont(font1);
		optionsWindow.add(sfx);

		JSlider sfxVol = new JSlider();
		sfxVol.setBounds(178, 68, 168, 23);
		optionsWindow.add(sfxVol);

		JLabel level = new JLabel("Level Volume");
		level.setBounds(62, 164, 106, 23);
		level.setForeground(Color.WHITE);
		level.setFont(font1);
		optionsWindow.add(level);

		JSlider levelVol = new JSlider();
		levelVol.setBounds(178, 164, 168, 23);
		optionsWindow.add(levelVol);

		JLabel controls = new JLabel("Controls:");
		controls.setBounds(62, 267, 64, 14);
		controls.setForeground(Color.WHITE);
		controls.setFont(font1);
		optionsWindow.add(controls);

		JLabel up = new JLabel("UP:");
		up.setBounds(140, 295, 46, 14);
		up.setForeground(Color.WHITE);
		up.setFont(font1);
		optionsWindow.add(up);

		JLabel w = new JLabel("W");
		w.setBounds(200, 295, 46, 14);
		w.setForeground(Color.WHITE);
		w.setFont(font1);
		optionsWindow.add(w);


		JLabel down = new JLabel("DOWN:");
		down.setBounds(140, 330, 50, 14);
		down.setForeground(Color.WHITE);
		down.setFont(font1);
		optionsWindow.add(down);

		JLabel s = new JLabel("S");
		s.setBounds(200, 330, 46, 14);
		s.setForeground(Color.WHITE);
		s.setFont(font1);
		optionsWindow.add(s);


		JLabel left = new JLabel("LEFT:");
		left.setBounds(140, 365, 46, 14);
		left.setForeground(Color.WHITE);
		left.setFont(font1);
		optionsWindow.add(left);

		JLabel a = new JLabel("A");
		a.setBounds(200, 365, 46, 14);
		a.setForeground(Color.WHITE);
		a.setFont(font1);
		optionsWindow.add(a);

		JLabel right = new JLabel("RIGHT:");
		right.setBounds(140, 400, 50, 14);
		right.setForeground(Color.WHITE);
		right.setFont(font1);
		optionsWindow.add(right);

		JLabel d = new JLabel("D");
		d.setBounds(200, 400, 46, 14);
		d.setForeground(Color.WHITE);
		d.setFont(font1);
		optionsWindow.add(d);

		JLabel plantBomb = new JLabel("PLANT BOMB:");
		plantBomb.setBounds(140, 435, 97, 14);
		plantBomb.setForeground(Color.WHITE);
		plantBomb.setFont(font1);
		optionsWindow.add(plantBomb);

		JLabel space = new JLabel("SPACE");
		space.setBounds(247, 435, 46, 14);
		space.setForeground(Color.WHITE);
		space.setFont(font1);
		optionsWindow.add(space);
	}

}


