package MenuWindows;

import java.awt.Color;
import java.awt.Font;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.SystemColor;

public class CreditsWindow extends JFrame {
	
	public CreditsWindow() {
		display();
	}
	
	public void display() {
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 600, 600);
		final Font font1 = new Font("Arial", Font.BOLD, 14);
		final Font font2 = new Font("Arial", Font.BOLD, 24);
		JPanel creditsWindow = new JPanel();
		creditsWindow.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(creditsWindow);
		creditsWindow.setLayout(null);
		creditsWindow.setBackground(SystemColor.activeCaption);
		JLabel title = new JLabel("Credits");
		title.setBounds(212, 11, 113, 34);
		title.setFont(font2);
		title.setForeground(Color.WHITE);
		creditsWindow.add(title);
		
		JLabel simon = new JLabel("Simon Krafft:");
		simon.setBounds(80, 80, 93, 14);
		simon.setFont(font1);
		simon.setForeground(Color.WHITE);
		creditsWindow.add(simon);
		
		JLabel wayne = new JLabel("Wayne Tam:");
		wayne.setBounds(80, 160, 93, 14);
		wayne.setFont(font1);
		wayne.setForeground(Color.WHITE);
		creditsWindow.add(wayne);
		
		JLabel sean = new JLabel("Sean Ryan:");
		sean.setBounds(80, 240, 93, 14);
		sean.setFont(font1);
		sean.setForeground(Color.WHITE);
		creditsWindow.add(sean);
		
		JLabel qianyu = new JLabel("Qianyu Liu:");
		qianyu.setBounds(80, 320, 93, 14);
		qianyu.setFont(font1);
		qianyu.setForeground(Color.WHITE);
		creditsWindow.add(qianyu);
		
		JLabel heng = new JLabel("Heng Kang:");
		heng.setBounds(80, 400, 93, 14);
		heng.setFont(font1);
		heng.setForeground(Color.WHITE);
		creditsWindow.add(heng);
	}
}
