package com.wayne.bomberman.objects;

import java.awt.Graphics;
import java.awt.Rectangle;
import java.util.LinkedList;

import com.wayne.bomberman.framework.GameObject;
import com.wayne.bomberman.framework.ObjectId;
import com.wayne.bomberman.framework.Position;
import com.wayne.bomberman.windows.Handler;

public class Power extends GameObject{

	private float width =32, height = 32;
	private Handler handler;
	
	public Power(Position p, float y, ObjectId id) {
		super(p, id);
		// TODO Auto-generated constructor stub
	}

	@Override
	public void tick(LinkedList<GameObject> object) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void render(Graphics g) {
		//g.drawImage(tex.block[0], (int) x, (int) y, null);
		
	}

	@Override
	public Rectangle getBounds() {
		return new Rectangle(position.x, position.y, 32,32); 
	}

	//increases player speed
	public void speedUp(){
		
		Player.speed=Player.speed*2;
	}
	
	//increases max bomb placement in an interval
	public void bombUp(){
		Player.nbBomb+=1;
	}
	
	//gives ability to kick the bomb
	public void bombKick(){
		Player.kick=true;
	}

	@Override
	public boolean isBombed(Bomb bomb) {
		// TODO Auto-generated method stub
		return false;
	}
}
