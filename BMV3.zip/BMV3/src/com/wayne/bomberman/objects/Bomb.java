package com.wayne.bomberman.objects;

import java.awt.Graphics;
import java.util.Timer;
import java.util.TimerTask;
import java.awt.Rectangle;
import java.util.LinkedList;

import com.wayne.bomberman.framework.GameObject;
import com.wayne.bomberman.framework.KeyInput;
import com.wayne.bomberman.framework.ObjectId;
import com.wayne.bomberman.framework.Position;
import com.wayne.bomberman.framework.Texture;
import com.wayne.bomberman.windows.Handler;
import com.wayne.bomberman.windows.game;

public class Bomb extends GameObject{

	Texture tex = game.getInstance();

	private float width =32, height = 32;
	private Handler handler;

	
	private final static float defaultTimer = 3;
	public static float timer = defaultTimer;
	
	private int defaultRange = 32;
	public int range = defaultRange;
	
	
	
	public Bomb(Position p, ObjectId id) {
		super(p, id);
		// TODO Auto-generated constructor stub
	}

	@Override
	public void tick(LinkedList<GameObject> object) {
	}

	@Override
	public void render(Graphics g) {
		// TODO Auto-generated method stub
		g.drawImage(tex.block[3], (int) position.x, (int) position.y, null);
	}

	@Override
	public Rectangle getBounds() {
		return new Rectangle((int) position.x, (int)position.y, 32,32); 
	}
	
	public void killTest(){
		int currentx = getPosition().getX();
		
	}
	
	public static boolean exploded(Bomb bomb,LinkedList<GameObject> object){
		if(bomb!=null&&System.currentTimeMillis()-KeyInput.tBomb>2000){
			
			for(int i=0;i<object.size();i++){
				if(object.get(i).isBombed(bomb)){
					object.remove(i);
				}
			}
			/*
			for(int i=0;i<melons.size();i++){
				if(melons.get(i).isBombed(bomb)){
				melons.remove(i);
				}
			}
			if(strawberry.isBombed(bomb)){
				strawberry.isHit();
			}*/
		KeyInput.spaceEnabled=true;
		return true;
		}
		else{
			return false;
		}
	}

	@Override
	public boolean isBombed(Bomb bomb) {
		// TODO Auto-generated method stub
		return false;
	}
}
