package com.wayne.bomberman.objects;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.util.LinkedList;

import com.wayne.bomberman.framework.GameObject;
import com.wayne.bomberman.framework.Intelligence;
import com.wayne.bomberman.framework.ObjectId;
import com.wayne.bomberman.framework.Position;
import com.wayne.bomberman.framework.Texture;
import com.wayne.bomberman.windows.Handler;
import com.wayne.bomberman.windows.game;

public class Enemy extends GameObject implements Intelligence {
	private int health;
	private int points;
	private int detectionRange=0;
	Texture tex = game.getInstance();

	private float width =32, height = 32;
	private Handler handler;
	public int speed = 3;
	//private Position position;

	public Enemy(Position p, Handler handler, ObjectId id) {
		super(p, id);
		this.handler = handler;
	}
	
	



	public void tick(LinkedList<GameObject> object) {
		
		position.x += velX;
		position.y += velY;
		
		Collision(object);
	}

	private void Collision(LinkedList<GameObject> object){
		
		for(int i = 0; i< handler.object.size(); i++){
			GameObject tempObject = handler.object.get(i);
			
			if(tempObject.getId() == ObjectId.Block){
				
				if(getBoundsTop().intersects(tempObject.getBounds()))
				{
					this.position.y = tempObject.position.getY() + 32;
				
				}
				
				if(getBounds().intersects(tempObject.getBounds()))
				{
					position.y = tempObject.position.getY() - (int) height;
				
				}
			
				//right
				if(getBoundsRight().intersects(tempObject.getBounds()))
				{
					position.x = tempObject.position.getX() - (int) width;
				
				}
				//left
				if(getBoundsLeft().intersects(tempObject.getBounds()))
				{
					position.x = tempObject.position.getX() + 32;
					
				}
			}
		}
	}

	///////////////////////////////////
	// NEEDS TO BE CHANGED FOR ENEMY?//
	///////////////////////////////////
	public void render(Graphics g) {
		//set color for player only when no texture file is available
		//g.setColor(Color.green);
		//g.fillRect((int)x, (int) y, (int) width, (int) height);
		
		//set texture for player if texture file is available
		g.drawImage(tex.enemy[0], position.x, position.y, null);
		
		Graphics2D g2d = (Graphics2D) g;
		//g.setColor(Color.red); // give color only when checking bounds, otherwise should be invisible
		g2d.draw(getBounds());
		g2d.draw(getBoundsRight());
		g2d.draw(getBoundsLeft());
		g2d.draw(getBoundsTop());
	}
	
	public Rectangle getBounds() {
		return new Rectangle((int) (position.getX()+(width/2)-((width/2)/2)), (int) ((int) position.getY()+(14)), (int) width/2, (int) height/2);
	}
	public Rectangle getBoundsTop() {
		return new Rectangle((int) (position.getX()+(width/2)-((width/2)/2)), (int) position.getY(), (int) width/2, (int) height/2);
	}
	public Rectangle getBoundsRight() {
		return new Rectangle((int) (position.getX()+width-5), (int) position.getY()+5, (int) 4, (int) height-12);
	}
	public Rectangle getBoundsLeft() {
		return new Rectangle((int) position.getX(), (int) position.getY()+1, (int) 4, (int) height-4);
	}



	public int getValue() {
		return this.points;
	}

	public void setValue(int pointsWorth) {
		this.points = pointsWorth;
	}

	public int getSpeed() {
		return this.speed;
	}

	public void setSpeed(int newSpeed) {
		this.speed = newSpeed;
	}

	public int getHealth() {
		return health;
	}

	public void setHealth(int health) {
		this.health = health;
	}

	public void isHit(boolean hit) {
		this.health--;
	}

	// new move methods for the AI
	// helper methods
	public void moveUpAI() {
		try {
			moveUp(this.speed);
			Thread.sleep(this.speed);
		}
		catch (InterruptedException e) {
			Thread.currentThread().interrupt(); 
		}
		finally {
			moveUp(0);
		}
	}
	public void moveDownAI() {
		try {
			moveDown(this.speed);
			Thread.sleep(this.speed);
		}
		catch (InterruptedException e) {
			Thread.currentThread().interrupt(); 
		}
		finally {
			moveDown(0);
		}
	}
	public void moveRightAI() {
		try {
			moveRight(this.speed);
			Thread.sleep(this.speed);
		}
		catch (InterruptedException e) {
			Thread.currentThread().interrupt(); 
		}
		finally {
			moveRight(0);
		}
	}
	public void moveLeftAI() {
		try {
			moveLeft(this.speed);
			Thread.sleep(this.speed);
		}
		catch (InterruptedException e) {
			Thread.currentThread().interrupt(); 
		}
		finally {
			moveLeft(0);
		}
	}



	//Simon

	
	
	public void setDetectionRange(int range) {
		this.detectionRange = range;
	}
	
	public int getDetectionRange() {
		return this.detectionRange;
	}
	
	public boolean detectPlayer(Player bomberman1) {
		int playerX = bomberman1.position.getX();
		int playerY = bomberman1.position.getY();
		int enemyX = this.position.getX();
		int enemyY = this.position.getY();
		int radius = getDetectionRange();
		int distanceFormula = (playerX-enemyX)*(playerX-enemyX)+(playerY-enemyY)*(playerY-enemyY);
		if(distanceFormula<=(radius*radius)) {
			return true;
		} else {
			return false;
		}
	}
	
	public void followPlayer(Player bomberman1, int range) {
		int playerX = bomberman1.position.getX();
		int playerY = bomberman1.position.getY();
		int enemyX = this.position.getX();
		int enemyY = this.position.getY();
		int xDist = Math.abs(enemyX - playerX);
		int yDist = Math.abs(enemyY - playerY);

		if (xDist > yDist) {
			if (enemyX > playerX) {
				moveLeftAI();
			}
			else {
				moveRightAI();
			}
		} 
		else {
			if (enemyY > playerY) {
				moveUpAI();
			}
			else {
				moveDownAI();
			}
		}
	}
	
	public boolean detectBomb(Bomb bomb1) {
		int bombX = bomb1.position.getX();
		int bombY = bomb1.position.getY();
		int enemyX = this.position.getX();
		int enemyY = this.position.getY();
		int radius = getDetectionRange();
		int distanceFormula = (bombX-enemyX)*(bombX-enemyX)+(bombY-enemyY)*(bombY-enemyY);
		if(distanceFormula<=(radius*radius)) {
			return true;
		} else {
			return false;
		}
	
	}

	public boolean detectBlockOnRight() {
		for(int i=0; i<handler.object.size();i++) {
			if((Math.abs(handler.object.get(i).position.getX()-this.position.getX()) < 40) && (handler.object.get(i).position.getX()-this.position.getX() > this.position.getX())) {   //checks if there is a block that is directly to the right of the enemy amongst all blocks on the map
				return true;
			}
		}
	 	return false;
	}

	public boolean detectBlockOnLeft() {
		for(int i=0; i<handler.object.size();i++) {
			if((Math.abs(handler.object.get(i).position.getX()-this.position.getX()) < 40) && (handler.object.get(i).position.getX()-this.position.getX() < this.position.getX())) {    //checks if there is a block that is directly to the left of the enemy amongst all blocks on the map
				return true;
			}
		}
	 	return false;
	}

	public boolean detectBlockAbove() {
		for(int i=0; i<handler.object.size();i++) {
			if((Math.abs(handler.object.get(i).position.getY()-this.position.getY()) < 40) && (handler.object.get(i).position.getY()-this.position.getY() < this.position.getY())) {    //checks if there is a block that is directly above the enemy amongst all blocks on the map
				return true;
			}
		}
	 	return false;
	}

	public boolean detectBlockUnder() {
		for(int i=0; i<handler.object.size();i++) {
			if((Math.abs(handler.object.get(i).position.getY()-this.position.getY()) < 40) && (handler.object.get(i).position.getX()-this.position.getX() > this.position.getX())) {	 //checks if there is a block that is directly under the enemy amongst all blocks on the map
				return true;
			}
		}
	 	return false;
	}



	
	public void avoidBomb(Bomb bomb1) {
		int bombX = bomb1.position.getX();
		int bombY = bomb1.position.getY();
		int enemyX = this.position.getX();
		int enemyY = this.position.getY();
		while (detectBomb(bomb1)) {
			if((Math.abs((bombY - enemyY)) >= Math.abs((bombX - enemyX))) && (bombY < enemyY)) {      //Bomb is above the enemy
				if(!detectBlockUnder())
					moveDownAI();
				else if(!detectBlockOnRight())
					moveRightAI();
				else 
					moveLeftAI();
			}
			
			else if((Math.abs((bombY - enemyY)) >= Math.abs((bombY - enemyY))) && (bombY > enemyY)) {   //Bomb is under
				if(!detectBlockAbove())
					moveUpAI();
				else if(!detectBlockOnRight())
					moveRightAI();
				else 
					moveLeftAI();
					
			}
			
			else if((Math.abs((bombY - enemyY)) <= Math.abs((bombY - enemyY))) && (bombX < enemyX)) {    //Bomb is to the left
				if(!detectBlockOnRight())
					moveRightAI();
				else if(!detectBlockAbove())
					moveUpAI();
				else 
					moveDownAI();
			}
			
			else if((Math.abs((bombY - enemyY)) <= Math.abs((bombY - enemyY))) && (bombX > enemyX)) {    //Bomb is to the right    
				if(!detectBlockOnLeft())
					moveLeftAI();
				else if(!detectBlockAbove())
					moveUpAI();
				else 
					moveDownAI();
			}
					
		}
	}





	@Override
	public boolean isBombed(Bomb bomb) {
		// TODO Auto-generated method stub
		return false;
	}
	
}