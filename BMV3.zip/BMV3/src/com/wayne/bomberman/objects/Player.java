package com.wayne.bomberman.objects;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.util.LinkedList;

import com.wayne.bomberman.framework.GameObject;
import com.wayne.bomberman.framework.ObjectId;
import com.wayne.bomberman.framework.Position;
import com.wayne.bomberman.framework.Texture;
import com.wayne.bomberman.windows.Handler;
import com.wayne.bomberman.windows.game;

public class Player extends GameObject {

	private int width =32, height = 32;
	
	private Handler handler;
	//player speed values
	private final static int defaultVel=2;
	public static int speed = defaultVel;
	
	//player bomb drops
	private final static float defaultNbBomb =1;
	public static float nbBomb=defaultNbBomb ;
	
	//player bomb kick ability
	private final static boolean defaultKick=false;
	public static boolean kick = defaultKick;
	
	Texture tex = game.getInstance();
	
	public Player(Position p, Handler handler, ObjectId id) {
		super(p, id);
		this.handler = handler;
		
	}

	public void tick(LinkedList<GameObject> object) {
		
		position.x += velX;
		position.y += velY;
		
		Collision(object);
	}
	
	private void Collision(LinkedList<GameObject> object){
		
		for(int i = 0; i< handler.object.size(); i++){
			GameObject tempObject = handler.object.get(i);
			
			if(tempObject.getId() == ObjectId.Block){
				
				if(getBoundsTop().intersects(tempObject.getBounds()))
				{
					position.y = tempObject.getPosition().getY() + 32;
				
				}
				
				if(getBounds().intersects(tempObject.getBounds()))
				{
					position.y = tempObject.getPosition().getY() - height;
				
				}
			
				//right
				if(getBoundsRight().intersects(tempObject.getBounds()))
				{
					position.x = tempObject.getPosition().getX() - width;
				
				}
				//left
				if(getBoundsLeft().intersects(tempObject.getBounds()))
				{
					position.x = tempObject.getPosition().getX() + 32;
					
				}
			}
		}
	}

	
	public void render(Graphics g) {
		//set color for player only when no texture file is available
		//g.setColor(Color.green);
		//g.fillRect((int)x, (int) y, (int) width, (int) height);
		
		//set texture for player if texture file is available
		g.drawImage(tex.player[0], (int)position.x, (int) position.y, null);
		
		Graphics2D g2d = (Graphics2D) g;
		//g.setColor(Color.red); // give color only when checking bounds, otherwise should be invisible
		g2d.draw(getBounds());
		g2d.draw(getBoundsRight());
		g2d.draw(getBoundsLeft());
		g2d.draw(getBoundsTop());
	}

//Boundaries 

		public Rectangle getBounds() {
			return new Rectangle((int) (position.getX()+(width/2)-((width/2)/2)), (int) ((int) position.getY()+(14)), (int) width/2, (int) height/2);
		}
		public Rectangle getBoundsTop() {
			return new Rectangle((int) (position.getX()+(width/2)-((width/2)/2)), (int) position.getY(), (int) width/2, (int) height/2);
		}
		public Rectangle getBoundsRight() {
			return new Rectangle((int) (position.getX()+width-5), (int) position.getY()+5, (int) 4, (int) height-12);
		}
		public Rectangle getBoundsLeft() {
			return new Rectangle((int) position.getX(), (int) position.getY()+1, (int) 4, (int) height-4);
		}

		@Override
		public boolean isBombed(Bomb bomb) {
			// TODO Auto-generated method stub
			return false;
		}

	

}
