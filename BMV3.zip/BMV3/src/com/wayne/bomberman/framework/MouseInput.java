package com.wayne.bomberman.framework;

import java.awt.Rectangle;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import com.wayne.bomberman.windows.game;


public class MouseInput implements MouseListener{

	public static int levelNum;
	@Override
	public void mousePressed(MouseEvent arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseEntered(MouseEvent arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseExited(MouseEvent arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseClicked(MouseEvent e) {
	
		int mx = e.getX();
		int my = e.getY();
		
///////////////////////////////////////////////////////////////////////////////////////////////
		//Mouse inputs for MENU
		if(game.State==STATE.MENU)
		{
			if(mx >=300 && mx<= 500)
			{
				if(my >=100 && my<= 150)
				{
					game.State= STATE.GAME;
				}
			}
		
			if(mx >=300 && mx<= 500)
			{
				if(my >=200 && my<= 250)
				{
					game.State= STATE.LEVELSELECT;
				}
			}
			//public Rectangle highscoreButton = new Rectangle(300,300,200,50);
			if(mx >=300 && mx<= 500)
			{
				if(my >=300 && my<= 350)
				{
					game.State= STATE.HIGHSCORE;
				}
			}
			//public Rectangle optionsButton = new Rectangle(300,400,200,50);
			if(mx >=300 && mx<= 500)
			{
				if(my >=400 && my<= 450)
				{
					game.State= STATE.HOWTOPLAY;
				}
			}
			
			if(mx >=300 && mx<= 500)
			{
				if(my >=500 && my<= 550)
				{
					System.exit(1);
				}
			}
		}
///////////////////////////////////////////////////////////////////////////////////////////////
		//Mouse buttons for LEVEL SELECT
		if(game.State==STATE.LEVELSELECT){
			if(mx >=365 && mx<= 520)//back to main menu
			{
				if(my >= 475 && my<= 525)
				{
					game.State = STATE.MENU;
				}
			}
		}
		if(game.State==STATE.LEVELSELECT){
			if(mx >=300 && mx<= 425)//back to main menu
			{
				if(my >= 100 && my<= 150)
				{
					game.State = STATE.GAME;
					levelNum=1;
				}
			}
		}
		if(game.State==STATE.LEVELSELECT){
			if(mx >=300 && mx<= 425)//back to main menu
			{
				if(my >= 175 && my<= 225)
				{
					game.State = STATE.GAME;
					levelNum=2;
				}
			}
		}
		if(game.State==STATE.LEVELSELECT){
			if(mx >=300 && mx<= 425)//back to main menu
			{
				if(my >= 250 && my<= 300)
				{
					game.State = STATE.GAME;
					levelNum=3;
				}
			}
		}
		if(game.State==STATE.LEVELSELECT){
			if(mx >=300 && mx<= 425)//back to main menu
			{
				if(my >= 325 && my<= 375)
				{
					game.State = STATE.GAME;
					levelNum=4;
				}
			}
		}
		if(game.State==STATE.LEVELSELECT){
			if(mx >=300 && mx<= 425)//back to main menu
			{
				if(my >= 400 && my<= 450)
				{
					game.State = STATE.GAME;
					levelNum=5;
				}
			}
		}
		if(game.State==STATE.LEVELSELECT){
			if(mx >=450 && mx<= 575)//back to main menu
			{
				if(my >= 100 && my<= 150)
				{
					game.State = STATE.GAME;
					levelNum=6;
				}
			}
		}
		if(game.State==STATE.LEVELSELECT){
			if(mx >=450 && mx<= 575)//back to main menu
			{
				if(my >= 175 && my<= 225)
				{
					game.State = STATE.GAME;
					levelNum=7;
				}
			}
		}
		if(game.State==STATE.LEVELSELECT){
			if(mx >=450 && mx<= 575)//back to main menu
			{
				if(my >= 250 && my<= 300)
				{
					game.State = STATE.GAME;
					levelNum=8;
				}
			}
		}
		if(game.State==STATE.LEVELSELECT){
			if(mx >=450 && mx<= 575)//back to main menu
			{
				if(my >= 325 && my<= 375)
				{
					game.State = STATE.GAME;
					levelNum=9;
				}
			}
		}
		if(game.State==STATE.LEVELSELECT){
			if(mx >=450 && mx<= 575)//back to main menu
			{
				if(my >= 400 && my<= 450)
				{
					game.State = STATE.GAME;
					levelNum=10;
				}
			}
		}
		
///////////////////////////////////////////////////////////////////////////////////////////////
		//Mouse buttons for How To Play
		if(game.State==STATE.HOWTOPLAY){
			if(mx >=365 && mx<= 520)
			{
				if(my >= 475 && my<= 530)
				{
					game.State = STATE.MENU;
				}
			}
		}
///////////////////////////////////////////////////////////////////////////////////////////////
		//Mouse buttons for highscores
		if(game.State==STATE.HIGHSCORE){
			if(mx >=365 && mx<= 520)
			{
				if(my >= 475 && my<= 530)
				{
					game.State = STATE.MENU;
				}
			}
		}
		
	}
///////////////////////////////////////////////////////////////////////////////////////////////

	
	
	@Override
	public void mouseReleased(MouseEvent arg0) {
		// TODO Auto-generated method stub
		
	}

}
