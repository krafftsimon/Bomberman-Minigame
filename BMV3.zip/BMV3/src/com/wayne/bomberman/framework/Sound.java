package com.wayne.bomberman.framework;

import java.applet.AudioClip;
import java.awt.image.BufferedImage;
import java.io.IOException;

import javax.imageio.ImageIO;

public class Sound {

	private AudioClip sound1;
	
	/*public void playSound(){
		//sound1= getAudioClip(getClass().getResource()("/path")); 
		//look up 
		
		public BufferedImage loadImage(String path){
			try {
				image = ImageIO.read(getClass().getResource(path));
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return image;
		}
	}*/
}
