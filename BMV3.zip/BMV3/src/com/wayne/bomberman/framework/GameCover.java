package com.wayne.bomberman.framework;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import Handlers.KeyEvents;

import java.awt.SystemColor;

public class GameCover extends JFrame
{

		
	public void render(Graphics g) 
	{
		
	}
}


