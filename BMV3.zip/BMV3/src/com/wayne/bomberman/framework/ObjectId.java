package com.wayne.bomberman.framework;

public enum ObjectId {//list of all objects

	Player(),
	Enemy(),
	Block(),
	Crate(),
	Bomb(),
	Power();
}
