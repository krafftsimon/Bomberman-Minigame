package com.wayne.bomberman.framework;

public interface Moveable {
	/*
	default void moveUp(int speed, Position current) {
		int yPos = current.getY();
		current.setY(++yPos);
		Thread.sleep(speed);
	}
	



	default void moveDown(int speed, Position current) {
		int yPos = current.getY();
		current.setY(--yPos);
		Thread.sleep(speed);
	}

	default void moveLeft(int speed, Position current) {
		int xPos = current.getX();
		current.setX(--xPos);
		Thread.sleep(speed);
	}

	default void moveRight(int speed, Position current) {
		int xPos = current.getX();
		current.setX(++xPos);
		Thread.sleep(speed);
	}
	*/
	void moveUp(int velocity);
	void moveDown(int velocity);
	void moveLeft(int velocity);
	void moveRight(int velocity);
	
}