package com.wayne.bomberman.menuwindows;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Rectangle;

import com.wayne.bomberman.framework.Texture;

public class levelSelect {
	
	//buttons
	public Rectangle level1Button = new Rectangle(300,100,125,50);//position x, position y, button width, button height
	public Rectangle level2Button = new Rectangle(300,175,125,50);
	public Rectangle level3Button = new Rectangle(300,250,125,50);
	public Rectangle level4Button = new Rectangle(300,325,125,50);
	public Rectangle level5Button = new Rectangle(300,400,125,50);
	public Rectangle level6Button = new Rectangle(450,100,125,50);
	public Rectangle level7Button = new Rectangle(450,175,125,50);
	public Rectangle level8Button = new Rectangle(450,250,125,50);
	public Rectangle level9Button = new Rectangle(450,325,125,50);
	public Rectangle level10Button = new Rectangle(450,400,125,50);
	public Rectangle backButton = new Rectangle(365,475,155,50);

	public void render(Graphics g){
			
		Graphics2D g2d = (Graphics2D) g;
		
		//title of level select
		Font font0 = new Font("arial", Font.BOLD, 30);
		g.setFont(font0);
		g.setColor(Color.red);
		
		//g.drawString("LEVEL SELECT",  325, 30);
			
		//buttons
		int a = 15;//horizontal position
		int b = 35;//vertical position
		Font font1 = new Font("arial", Font.BOLD, 25);
		g.setFont(font1);;
		g.drawString("Level 1", level1Button.x+a, level1Button.y+b);
		g2d.draw(level1Button);
		g.drawString("Level 2", level2Button.x+a, level2Button.y+b);
		g2d.draw(level2Button);
		g.drawString("Level 3", level3Button.x+a, level3Button.y+b);
		g2d.draw(level3Button);
		g.drawString("Level 4", level4Button.x+a, level4Button.y+b);
		g2d.draw(level4Button);
		g.drawString("Level 5", level5Button.x+a, level5Button.y+b);
		g2d.draw(level5Button);
		g.drawString("Level 6", level6Button.x+a, level6Button.y+b);
		g2d.draw(level6Button);
		g.drawString("Level 7", level7Button.x+a, level7Button.y+b);
		g2d.draw(level7Button);
		g.drawString("Level 8", level8Button.x+a, level8Button.y+b);
		g2d.draw(level8Button);
		g.drawString("Level 9", level9Button.x+a, level9Button.y+b);
		g2d.draw(level9Button);
		g.drawString("Level 10", level10Button.x+a, level10Button.y+b);
		g2d.draw(level10Button);
		g.drawString("Main Menu", backButton.x+a, backButton.y+b);
		g2d.draw(backButton);

	
	}
}



