package com.wayne.bomberman.menuwindows;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Rectangle;

public class HowToPlay {
	//buttons

		public Rectangle backButton = new Rectangle(365,475,155,50);

		public void render(Graphics g){
				
			Graphics2D g2d = (Graphics2D) g;
			
			//title of level select
			Font font0 = new Font("arial", Font.BOLD, 30);
			g.setFont(font0);
			g.setColor(Color.red);
			
			//g.drawString("HOW TO PLAY",  325, 30);
				
			//buttons
			int a = 15;//horizontal position
			int b = 35;//vertical position
			Font font1 = new Font("arial", Font.BOLD, 25);
			g.setFont(font1);
			g.drawString("Main Menu", backButton.x+a, backButton.y+b);
			g2d.draw(backButton);

		
		}
}
