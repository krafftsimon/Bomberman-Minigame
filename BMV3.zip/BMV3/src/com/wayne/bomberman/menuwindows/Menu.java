package com.wayne.bomberman.menuwindows;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Rectangle;

public class Menu {

	//buttons
	public Rectangle playButton = new Rectangle(300,100,200,50);//position x, position y, button width, button height
	public Rectangle levelButton = new Rectangle(300,200,200,50);
	public Rectangle highscoreButton = new Rectangle(300,300,200,50);
	public Rectangle optionsButton = new Rectangle(300,400,200,50);
	public Rectangle exitButton = new Rectangle(300,500,200,50);

	public void render(Graphics g){
		
		Graphics2D g2d = (Graphics2D) g;
		
		//title of menu
		Font font0 = new Font("arial", Font.BOLD, 30);
		g.setFont(font0);
		g.setColor(Color.red);
		g.drawString("Main Menu",  325, 30);
		
		//buttons
		Font font1 = new Font("arial", Font.BOLD, 25);
		g.setFont(font1);;
		g.drawString("Play", playButton.x+70, playButton.y+35);
		g2d.draw(playButton);
		g.drawString("Level Select", levelButton.x+30, levelButton.y+35);
		g2d.draw(levelButton);
		g.drawString("Highscore", highscoreButton.x+40, highscoreButton.y+35);
		g2d.draw(highscoreButton);
		g.drawString("How to Play", optionsButton.x+35, optionsButton.y+35);
		g2d.draw(optionsButton);
		g.drawString("Exit Game", exitButton.x+40, exitButton.y+35);
		g2d.draw(exitButton);
	}
}
