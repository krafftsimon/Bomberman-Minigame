package com.wayne.bomberman.windows;

import java.awt.Graphics;
import java.util.LinkedList;

import com.wayne.bomberman.framework.GameObject;
import com.wayne.bomberman.objects.*;

public class Handler {

	public LinkedList<GameObject> object = new LinkedList<GameObject>();

	private GameObject tempObject;
	
	public static Bomb bomb = null;
	
	public void tick(){
		for(int i=0;i<object.size(); i++){
			tempObject = object.get(i);
			tempObject.tick(object);
		}
		if(Bomb.exploded(bomb, object)){
			bomb=null;
		}
	}
	
	public void render(Graphics g){
		for(int i=0;i<object.size(); i++){
			tempObject = object.get(i);
			
			tempObject.render(g);
		}
		if(bomb!=null){
		bomb.render(g);
		}
		
	}
	
	public void addObject(GameObject object){
		
		this.object.add(object);
	}


	public void removeObject(GameObject object){
		this.object.remove(object);
	}
	
}
