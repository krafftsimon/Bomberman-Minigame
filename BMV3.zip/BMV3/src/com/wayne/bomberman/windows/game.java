package com.wayne.bomberman.windows;

import java.awt.Canvas;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.image.BufferStrategy;
import java.awt.image.BufferedImage;
import java.util.Random;
import java.util.Scanner;

import com.wayne.bomberman.framework.GameCover;
import com.wayne.bomberman.framework.KeyInput;
import com.wayne.bomberman.framework.MouseInput;
import com.wayne.bomberman.framework.ObjectId;
import com.wayne.bomberman.framework.Position;
import com.wayne.bomberman.framework.STATE;
import com.wayne.bomberman.framework.Texture;
import com.wayne.bomberman.menuwindows.Highscores;
import com.wayne.bomberman.menuwindows.HowToPlay;
import com.wayne.bomberman.menuwindows.Menu;
import com.wayne.bomberman.menuwindows.levelSelect;
import com.wayne.bomberman.objects.Block;
import com.wayne.bomberman.objects.Crate;
import com.wayne.bomberman.objects.Enemy;
import com.wayne.bomberman.objects.Player;


public class game extends Canvas implements Runnable{

	private static final long serialVersionUID = -7203659715208503182L;

	private boolean running =false;
	private Thread thread;
	
	public static int WIDTH, HEIGHT;

	//create states here
	private Menu menu= new Menu();
	private levelSelect select = new levelSelect();
	private HowToPlay htp = new HowToPlay();
	private Highscores hs = new Highscores();
	private GameCover gc = new GameCover();
	
	//all necessary objects here
	Handler handler;
	static Texture tex;
	public static STATE State = STATE.GAMECOVER;
	
	int gameLoop=1;//for looping once on init() 	
	
	private void init()
	{
		WIDTH =getWidth();
		HEIGHT=getHeight();
		tex = new Texture();
		
		handler = new Handler(); 
		
		for(int i=1;i<=10;i++){
			if(MouseInput.levelNum == i)
				LoadImageLevel(tex.level[i-1]);
			}
			
		this.addMouseListener(new MouseInput());	
		this.addKeyListener(new KeyInput(handler));
	}
		
	public synchronized void start(){
		if(running)
			return;
		running =true;
		thread = new Thread(this);
		thread.start();
		
	}
	
	public void run()//game loop
	{
		init();
		
		this.requestFocus();
		
		long lastTime = System.nanoTime();
		double nbTicks = 50;
		double ns = 1000000000 / nbTicks;
		double time = 0;
		while(running){
			long now = System.nanoTime();
			time += (now - lastTime) / ns;
			lastTime = now;
			while(time >= 1){
				tick();	
				time--;
			}
			render();
			}
	}
	
	private void tick()//game updates
	{
		if(State==STATE.GAME)
		{
			handler.tick();
		}
		
		
	}
	
	private void render()//graphics, drawing, images
	{
		BufferStrategy bs = this.getBufferStrategy();
		
		if(bs==null)
		{
			createBufferStrategy(3);
			return;
		}
		
		Graphics g = bs.getDrawGraphics();
		
		if(State==STATE.GAME){
			if(gameLoop==1)//only for game cycle, so that it goes through init only once
			{
				gameLoop=0;
				init();
			}
			g.setColor(Color.darkGray);//IN GAME background
			g.fillRect(0, 0, getWidth(), getHeight());// window dimensions
			handler.render(g); 
			g.setColor(Color.red);
			g.drawImage(tex.hud[0], 0, 476, null);//score hud
			g.setFont(new Font("TimesRoman", Font.PLAIN, 38)); 
			g.drawString("1000000000",380,520);
		}else if(State==STATE.MENU){
			g.setColor(Color.black);//menu background
			
			g.fillRect(0, 0, getWidth(), getHeight());
			//g.drawImage(tex.cover[0],5, 0, null);
			menu.render(g);
			
		}else if(State==STATE.LEVELSELECT){
			g.setColor(Color.black);// background
			g.fillRect(0, 0, getWidth(), getHeight());
			g.drawImage(tex.menu_icons[0], 0, 100, null);//bomberman icon
			g.drawImage(tex.menu_icons[1], 325, 0, null);//level icon
			select.render(g);
		}else if(State==STATE.HOWTOPLAY){
			g.setColor(Color.black);
			g.fillRect(0, 0, getWidth(), getHeight());
			g.drawImage(tex.menu_icons[0], 0, 100, null);//bomberman icon
			g.setColor(Color.red);
			g.setFont(new Font("TimesRoman", Font.PLAIN, 38)); 
			g.drawString("error, please contact internet police", 100, 30);
			htp.render(g);
		}else if(State==STATE.HIGHSCORE){
			g.setColor(Color.black);
			g.fillRect(0, 0, getWidth(), getHeight());
			hs.render(g);
		}else if(State==STATE.GAMECOVER){
			g.setColor(Color.black);
			g.fillRect(0, 0, getWidth(), getHeight());
			g.drawImage(tex.cover[0],5, 0, null);
			//gc.render(g);
		}
		
		g.dispose();
		bs.show();
	}
	
	private void LoadImageLevel(BufferedImage image)
	{
		if(State==STATE.GAME)
		{
			//only for testing, checks for file dimension size
			int w = image.getWidth();
			int h = image.getHeight();
			System.out.println("width, height: " + w + " " + h);
			//test stops here
			
			
			for(int xx= 0; xx<h; xx++)
			{//level design by colors
				for(int yy=0;yy<w; yy++)
				{
					int pixel = image.getRGB(xx,  yy);
					int red = (pixel >>16) & 0xff;
					int green=(pixel >> 8) & 0xff;
					int blue =(pixel) & 0xff;
					
					//check1
					Position p = new Position(xx*32, yy*32);
					if(red == 128 && green ==128 && blue ==128) handler.addObject(new Block(p,4, ObjectId.Block));
					if(red == 255 && green ==255 && blue ==255) handler.addObject(new Block(p,0, ObjectId.Block));//block bounderies
					if(red == 255 && green ==255 && blue ==0) handler.addObject(new Block(p,1, ObjectId.Block));//structure blocks 
					if(red == 255 && green ==0 && blue ==0) handler.addObject(new Crate(p,0, ObjectId.Block));//destructible blocks
					if(red == 0 && green ==0 && blue ==255) handler.addObject(new Player(p,handler, ObjectId.Player));//player
					if(red == 0 && green ==255 && blue ==0) handler.addObject(new Enemy(p,handler, ObjectId.Enemy));//player
				}
			}
		}
	}
	
	public static Texture getInstance(){
		return tex;
	}
	
	public static void main(String args[]) {
		new window(800, 600, "Bomberman model", new game());
		
	}
}
